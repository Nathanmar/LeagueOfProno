
  # League of Prono Platform

  This is a code bundle for League of Prono Platform. The original project is available at https://www.figma.com/design/YD0NUPmH9HU0c0az6AAf5W/League-of-Prono-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  